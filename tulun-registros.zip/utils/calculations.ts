
import { TarifaConfig } from '../types';

export const calculateFee = (km: number, config: TarifaConfig): number => {
  // Check within fixed ranges
  const matchedRange = config.ranges.find(r => km >= r.minKm && km <= r.maxKm);
  
  if (matchedRange) {
    return matchedRange.price;
  }

  // If outside fixed ranges and increment is defined
  if (config.baseIncrementKm && config.incrementPrice) {
    const maxRangePrice = config.ranges[config.ranges.length - 1].price;
    const extraKm = km - config.baseIncrementKm;
    if (extraKm > 0) {
      // Round up to nearest 3km interval if the rule is "por cada 3km adicionales"
      const increments = Math.ceil(extraKm / 3);
      return maxRangePrice + (increments * config.incrementPrice);
    }
    return maxRangePrice;
  }

  // Fallback for types like Mensajeria that don't have infinite increments defined in the prompt
  return config.ranges[config.ranges.length - 1].price;
};
