
import { jsPDF } from 'jspdf';
import autoTable from 'jspdf-autotable';
import { Carrera, CarreraStatus } from '../types';

type ReportType = 'motorizado' | 'restaurant' | 'general';

export const generateReport = (title: string, data: Carrera[], type: ReportType) => {
  try {
    const doc = new jsPDF();
    const approvedCarreras = data.filter(c => c.status === CarreraStatus.APROBADA || c.status === CarreraStatus.LIQUIDADA);
    
    // Estilo de Cabecera
    doc.setFontSize(22);
    doc.setTextColor(30, 41, 59); // Slate 800
    doc.text(title, 14, 22);
    
    doc.setFontSize(10);
    doc.setTextColor(100, 116, 139); // Slate 500
    doc.text(`Generado: ${new Date().toLocaleString()}`, 14, 30);
    doc.text(`Registros: ${approvedCarreras.length}`, 14, 35);

    let head: string[][] = [];
    let body: string[][] = [];
    let footerLabel = "";
    let footerValue = 0;

    if (type === 'motorizado') {
      head = [['Fecha', 'Local', 'Cliente', 'Destino (Punto B)', 'KM', 'Pago Mot.']];
      body = approvedCarreras.map(c => [
        new Date(c.date).toLocaleDateString(),
        c.restaurantName,
        c.clientName,
        c.pointB,
        `${c.km} KM`,
        `$${(c.motorizadoEarnings || 0).toFixed(2)}`
      ]);
      footerLabel = "Total Ganado por Motorizado";
      footerValue = approvedCarreras.reduce((sum, c) => sum + (c.motorizadoEarnings || 0), 0);
    } else if (type === 'restaurant') {
      head = [['Cliente', 'Fecha', 'Motorizado', 'Distancia', 'Tarifa']];
      body = approvedCarreras.map(c => [
        c.clientName,
        new Date(c.date).toLocaleDateString(),
        c.motorizadoName,
        `${c.km} KM`,
        `$${c.price.toFixed(2)}`
      ]);
      footerLabel = "Total Facturado al Local";
      footerValue = approvedCarreras.reduce((sum, c) => sum + c.price, 0);
    } else {
      head = [['Motorizado', 'Local', 'KM', 'Pago Mot.', 'Pago Local', 'Ganancia']];
      body = approvedCarreras.map(c => [
        c.motorizadoName,
        c.restaurantName,
        `${c.km} KM`,
        `$${(c.motorizadoEarnings || 0).toFixed(2)}`,
        `$${c.price.toFixed(2)}`,
        `$${(c.price - (c.motorizadoEarnings || 0)).toFixed(2)}`
      ]);
      footerLabel = "Utilidad Neta del Sistema";
      const totalRev = approvedCarreras.reduce((sum, c) => sum + c.price, 0);
      const totalCost = approvedCarreras.reduce((sum, c) => sum + (c.motorizadoEarnings || 0), 0);
      footerValue = totalRev - totalCost;
    }

    autoTable(doc, {
      startY: 45,
      head: head,
      body: body,
      theme: 'grid',
      headStyles: { 
        fillColor: type === 'motorizado' ? [16, 185, 129] : (type === 'restaurant' ? [79, 70, 229] : [30, 41, 59]),
        fontSize: 9
      },
      styles: { fontSize: 8 }
    });

    const finalY = (doc as any).lastAutoTable?.finalY || 100;
    doc.setFont("helvetica", "bold");
    doc.text(`${footerLabel}: $${footerValue.toFixed(2)}`, 14, finalY + 15);

    const fileName = title.toLowerCase().replace(/ /g, '_') + '.pdf';
    doc.save(fileName);
  } catch (e) {
    console.error(e);
    alert("Error al generar el reporte");
  }
};
