
import React, { useState } from 'react';
import { Carrera, Restaurant, CarreraStatus, Liquidacion, LiquidacionStatus, IncentiveChallenge, RewardType, User } from '../types';

interface MotorizadoPanelProps {
  user: User;
  onUpdateUser: (user: User) => void;
  carreras: Carrera[];
  restaurants: Restaurant[];
  liquidaciones: Liquidacion[];
  incentives: IncentiveChallenge[];
  onSave: (data: Partial<Carrera>) => void;
  onRequestPayment: (amount: number) => void;
  onClaimReward: (incentive: IncentiveChallenge) => void;
}

const MotorizadoPanel: React.FC<MotorizadoPanelProps> = ({ user, onUpdateUser, carreras, restaurants, liquidaciones, incentives, onSave, onRequestPayment, onClaimReward }) => {
  const [step, setStep] = useState<'list' | 'select_restaurant' | 'form' | 'payments' | 'challenges' | 'profile'>('list');
  const [selectedRestaurant, setSelectedRestaurant] = useState<Restaurant | null>(null);
  const [clientName, setClientName] = useState('');
  const [pointA, setPointA] = useState('');
  const [pointB, setPointB] = useState('');
  const [km, setKm] = useState<string>('');
  
  // Profile settings state
  const [newPass, setNewPass] = useState('');
  const [confirmPass, setConfirmPass] = useState('');
  const [passMsg, setPassMsg] = useState('');
  const [isDevMode, setIsDevMode] = useState(false);

  const todayDate = new Date();
  const todayStr = todayDate.toISOString().split('T')[0];
  
  const approvedTodayCount = carreras.filter(c => 
    (c.status === CarreraStatus.APROBADA || c.status === CarreraStatus.LIQUIDADA) && 
    c.date.startsWith(todayStr) && 
    c.restaurantId !== 'incentivo'
  ).length;

  const approvedEarnings = carreras
    .filter(c => c.status === CarreraStatus.APROBADA && !c.liquidacionId)
    .reduce((sum, c) => sum + (c.motorizadoEarnings || 0), 0);

  const pendingEarnings = carreras
    .filter(c => c.status === CarreraStatus.PENDIENTE)
    .reduce((sum, c) => sum + (c.motorizadoEarnings || 0), 0);

  const handleSave = () => {
    if (!selectedRestaurant || !clientName || !pointA || !pointB || !km) return;
    onSave({ restaurantId: selectedRestaurant.id, clientName, pointA, pointB, km: parseFloat(km) });
    setStep('list');
    setClientName(''); setPointA(''); setPointB(''); setKm('');
  };

  const validateAndRequestPayment = () => {
    const now = new Date();
    const isTuesday = now.getDay() === 2; // Martes
    const isAfter11 = now.getHours() >= 11;

    if (!isDevMode && (!isTuesday || !isAfter11)) {
      alert("No es fecha de pago. Los pagos solo se pueden solicitar los martes después de las 11:00 AM.");
      return;
    }

    if (confirm(`¿Confirmas la solicitud de pago por $${approvedEarnings.toFixed(2)}?`)) {
      onRequestPayment(approvedEarnings);
    }
  };

  const handleUpdatePassword = () => {
    if (newPass !== confirmPass) { setPassMsg("Las contraseñas no coinciden"); return; }
    if (newPass.length < 4) { setPassMsg("Contraseña muy corta"); return; }
    onUpdateUser({ ...user, password: newPass });
    setPassMsg("¡Contraseña actualizada!");
    setNewPass(''); setConfirmPass('');
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <div className="flex justify-center mb-6">
        <div className="bg-white p-1 rounded-xl shadow-sm border flex overflow-x-auto no-scrollbar">
           <TabNav label="Historial" active={step === 'list'} onClick={() => setStep('list')} />
           <TabNav label="Premios" active={step === 'challenges'} onClick={() => setStep('challenges')} badge={incentives.length} />
           <TabNav label="Liquidaciones" active={step === 'payments'} onClick={() => setStep('payments')} />
           <TabNav label="Ajustes" active={step === 'profile'} onClick={() => setStep('profile')} />
        </div>
      </div>

      {step === 'list' && (
        <div className="space-y-6 animate-in fade-in duration-500">
          <div className="bg-slate-900 text-white p-6 rounded-3xl shadow-xl">
            <div className="grid grid-cols-2 gap-4 mb-6">
               <div className="bg-white/10 p-4 rounded-2xl border border-white/5">
                 <p className="text-[10px] font-bold uppercase opacity-60 mb-1">Caja Disponible</p>
                 <h3 className="text-3xl font-black text-emerald-400">${approvedEarnings.toFixed(2)}</h3>
               </div>
               <div className="bg-white/10 p-4 rounded-2xl border border-white/5">
                 <p className="text-[10px] font-bold uppercase opacity-60 mb-1">En Revisión</p>
                 <h3 className="text-3xl font-black text-amber-400">${pendingEarnings.toFixed(2)}</h3>
               </div>
            </div>
            <button disabled={approvedEarnings <= 0} onClick={validateAndRequestPayment} className="w-full bg-indigo-600 py-4 rounded-2xl text-sm font-black disabled:opacity-30 uppercase tracking-widest shadow-lg active:scale-95 transition-all">Solicitar Cobro</button>
            <p className="text-[9px] text-center mt-3 text-slate-500 uppercase font-bold italic tracking-wider">Ciclo de pagos: Martes 11:00 AM</p>
          </div>

          <button onClick={() => setStep('select_restaurant')} className="w-full bg-white border-2 border-slate-900 text-slate-900 py-4 rounded-2xl font-black shadow-lg flex items-center justify-center space-x-2 active:scale-95 transition-all">
            <i className="fas fa-plus-circle text-indigo-600 text-xl"></i><span>REGISTRAR CARRERA</span>
          </button>
          
          <div className="space-y-3">
             <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest">Movimientos Hoy</h4>
             {carreras.filter(c => c.date.startsWith(todayStr)).map(c => (
               <div key={c.id} className="p-4 bg-white border border-slate-100 rounded-2xl flex justify-between items-center shadow-sm">
                  <div className="overflow-hidden">
                    <p className="text-sm font-bold text-slate-800 truncate">{c.restaurantName}</p>
                    <p className="text-[10px] text-slate-400 font-bold uppercase truncate">{c.clientName}</p>
                  </div>
                  <div className="text-right whitespace-nowrap">
                    <p className="text-sm font-black text-slate-800">${(c.motorizadoEarnings || 0).toFixed(2)}</p>
                    <span className={`text-[8px] font-black uppercase px-2 py-0.5 rounded-full ${c.status === CarreraStatus.PENDIENTE ? 'bg-amber-100 text-amber-700' : 'bg-emerald-100 text-emerald-700'}`}>{c.status}</span>
                  </div>
               </div>
             ))}
             {carreras.filter(c => c.date.startsWith(todayStr)).length === 0 && (
               <p className="text-center py-10 text-slate-300 italic text-xs">Sin actividad hoy</p>
             )}
          </div>
        </div>
      )}

      {step === 'challenges' && (
        <div className="space-y-6 animate-in slide-in-from-right-4 duration-300">
          <h2 className="text-2xl font-black text-slate-800">Metas y Desafíos</h2>
          <div className="grid grid-cols-1 gap-4">
            {incentives.map(inc => {
              const progress = Math.min((approvedTodayCount / inc.goal) * 100, 100);
              const isCompleted = approvedTodayCount >= inc.goal;
              const claimKey = `PREMIO: ${inc.title}`;
              const claimEntry = carreras.find(c => c.clientName === claimKey && c.status !== CarreraStatus.RECHAZADA);
              const isClaimed = !!claimEntry;

              return (
                <div key={inc.id} className="bg-white p-6 rounded-3xl border-2 border-slate-100 shadow-sm relative overflow-hidden">
                  <div className="flex justify-between items-start mb-4">
                     <div className="max-w-[70%]">
                        <h3 className="text-lg font-black text-slate-800 leading-tight uppercase tracking-tight">{inc.title}</h3>
                        <p className="text-xs text-slate-500 mt-1">{inc.description}</p>
                     </div>
                     <div className="bg-amber-100 text-amber-700 px-3 py-1 rounded-full text-[10px] font-black uppercase ring-1 ring-amber-300 shadow-sm">
                        ${inc.rewardValue}
                     </div>
                  </div>
                  <div className="space-y-2">
                    <div className="w-full h-4 bg-slate-100 rounded-full overflow-hidden border">
                      <div className="h-full bg-indigo-500 transition-all duration-700 shadow-inner" style={{ width: `${progress}%` }}></div>
                    </div>
                    <div className="flex justify-between text-[9px] font-bold text-slate-400 uppercase tracking-widest">
                      <span>Objetivo: {inc.goal} carreras</span>
                      <span>Progreso: {approvedTodayCount} / {inc.goal}</span>
                    </div>
                  </div>
                  {isCompleted && !isClaimed && (
                    <button 
                      onClick={() => onClaimReward(inc)}
                      className="w-full mt-6 bg-emerald-600 text-white font-black py-4 rounded-2xl shadow-lg shadow-emerald-100 uppercase text-xs tracking-widest animate-bounce"
                    >
                      <i className="fas fa-gift mr-2"></i>Reclamar Premio Ahora
                    </button>
                  )}
                  {isClaimed && (
                    <div className={`w-full mt-6 py-4 rounded-2xl text-center uppercase text-[10px] font-black tracking-widest border-2 border-dashed ${claimEntry?.status === CarreraStatus.APROBADA ? 'bg-emerald-50 text-emerald-600 border-emerald-200' : 'bg-slate-50 text-slate-400 border-slate-200'}`}>
                      {claimEntry?.status === CarreraStatus.APROBADA ? (
                        <span><i className="fas fa-check-circle mr-2"></i>¡Premio Acreditado!</span>
                      ) : (
                        <span><i className="fas fa-clock mr-2"></i>Esperando Aprobación del Admin</span>
                      )}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {step === 'profile' && (
        <div className="bg-white p-8 rounded-3xl border shadow-sm animate-in fade-in duration-300">
           <h2 className="text-2xl font-black mb-6 text-slate-800">Ajustes del Motorizado</h2>
           <div className="space-y-6 max-w-md">
              <div className="p-5 bg-indigo-50 rounded-2xl border border-indigo-100 shadow-inner">
                 <p className="text-xs font-bold text-indigo-700 uppercase mb-1">Nombre Completo</p>
                 <p className="font-black text-slate-800 text-lg">{user.name}</p>
                 <div className="pt-4 border-t border-indigo-200 flex items-center justify-between mt-4">
                    <div><p className="text-xs font-bold text-slate-800 uppercase">Salto de Seguridad</p><p className="text-[9px] text-slate-400 italic font-medium">Permitir cobros fuera de horario habitual</p></div>
                    <button onClick={() => setIsDevMode(!isDevMode)} className={`w-12 h-6 rounded-full relative transition-colors ${isDevMode ? 'bg-indigo-600' : 'bg-slate-300'}`}><div className={`absolute top-1 w-4 h-4 bg-white rounded-full shadow-sm transition-all ${isDevMode ? 'left-7' : 'left-1'}`}></div></button>
                 </div>
              </div>
              <div className="space-y-4 pt-4 border-t">
                 <h3 className="font-black text-slate-800 uppercase text-xs tracking-widest">Cambiar Seguridad</h3>
                 <InputField label="Nueva Contraseña" type="password" value={newPass} onChange={setNewPass} placeholder="••••••••" />
                 <InputField label="Confirmar" type="password" value={confirmPass} onChange={setConfirmPass} placeholder="••••••••" />
                 {passMsg && <p className={`text-xs font-bold p-2 bg-slate-50 rounded-lg border text-center ${passMsg.includes('¡') ? 'text-emerald-600 border-emerald-100' : 'text-red-600 border-red-100'}`}>{passMsg}</p>}
                 <button onClick={handleUpdatePassword} className="bg-slate-900 text-white px-6 py-4 rounded-2xl font-black text-xs uppercase w-full shadow-xl transition-all active:scale-95">Guardar Cambios</button>
              </div>
           </div>
        </div>
      )}

      {step === 'select_restaurant' && (
        <div className="animate-in fade-in duration-300">
          <button onClick={() => setStep('list')} className="mb-6 text-slate-400 font-bold flex items-center space-x-2"><i className="fas fa-arrow-left"></i><span>Volver</span></button>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
            {restaurants.map(r => (
              <button key={r.id} onClick={() => { setSelectedRestaurant(r); setStep('form'); }} className="h-44 rounded-3xl overflow-hidden border-2 border-slate-100 shadow-sm relative group">
                <img src={r.imageUrl || 'https://via.placeholder.com/150'} className="w-full h-full object-cover brightness-75 group-hover:scale-110 transition-all duration-500" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent flex items-end p-4"><p className="text-white font-black text-[10px] text-left uppercase leading-tight tracking-wider">{r.name}</p></div>
              </button>
            ))}
          </div>
        </div>
      )}

      {step === 'form' && selectedRestaurant && (
        <div className="bg-white p-6 rounded-3xl shadow-2xl border animate-in zoom-in-95 duration-300">
          <div className="flex items-center gap-4 mb-10 border-b pb-6">
             <img src={selectedRestaurant.imageUrl || 'https://via.placeholder.com/150'} className="w-20 h-20 object-cover rounded-2xl shadow-xl border-2 border-indigo-50" />
             <div>
                <p className="text-[10px] font-black text-indigo-500 uppercase">Nueva Carrera</p>
                <h2 className="text-2xl font-black text-slate-800 uppercase leading-none">{selectedRestaurant.name}</h2>
             </div>
          </div>
          <div className="space-y-5">
            <InputField label="Nombre del Cliente" value={clientName} onChange={setClientName} placeholder="Cliente" />
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
               <InputField label="Origen" value={pointA} onChange={setPointA} placeholder="Origen" />
               <InputField label="Destino" value={pointB} onChange={setPointB} placeholder="Destino" />
            </div>
            <InputField label="Distancia Real (KM)" value={km} onChange={setKm} placeholder="0.0" type="number" />
            <button onClick={handleSave} className="w-full bg-indigo-600 text-white font-black py-5 rounded-3xl shadow-xl mt-6 uppercase tracking-widest active:scale-95 transition-all">Registrar Carrera</button>
            <button onClick={() => setStep('list')} className="w-full py-3 text-slate-400 font-bold uppercase text-[10px] tracking-widest">Descartar</button>
          </div>
        </div>
      )}

      {step === 'payments' && (
        <div className="animate-in fade-in duration-300">
           <h2 className="text-xl font-bold mb-6">Mis Liquidaciones</h2>
           <div className="space-y-4">
              {liquidaciones.map(liq => (
                 <div key={liq.id} className="p-5 bg-white border border-slate-100 rounded-3xl shadow-sm flex justify-between items-center transition-all hover:border-indigo-200">
                    <div>
                      <p className="text-[10px] font-bold text-indigo-600 uppercase">Ref: {liq.id}</p>
                      <p className="text-xl font-black text-slate-800">${liq.amount.toFixed(2)}</p>
                      <p className="text-[10px] text-slate-400">{new Date(liq.date).toLocaleDateString()}</p>
                    </div>
                    <span className={`text-[10px] font-black uppercase px-4 py-1.5 rounded-full ${liq.status === LiquidacionStatus.PAGADA ? 'bg-emerald-100 text-emerald-700' : 'bg-amber-100 text-amber-700'}`}>{liq.status}</span>
                 </div>
              ))}
           </div>
        </div>
      )}
    </div>
  );
};

const TabNav = ({ label, active, onClick, badge }: any) => (
  <button onClick={onClick} className={`px-5 py-2.5 rounded-xl text-xs font-black uppercase tracking-widest transition-all flex items-center gap-1.5 whitespace-nowrap ${active ? 'bg-indigo-600 text-white shadow-lg' : 'text-slate-400 hover:bg-slate-50'}`}>
    {label}
    {badge > 0 && <span className="bg-red-500 text-white text-[9px] w-4 h-4 flex items-center justify-center rounded-full shadow-sm">{badge}</span>}
  </button>
);

const InputField = ({ label, value, onChange, placeholder, type = 'text' }: any) => (
  <div className="space-y-1.5">
    <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">{label}</label>
    <input type={type} step="0.01" className="w-full px-5 py-3.5 bg-slate-50 border border-slate-200 rounded-2xl text-sm font-medium outline-none focus:border-indigo-500 focus:bg-white transition-all shadow-sm" value={value} onChange={e => onChange(e.target.value)} placeholder={placeholder} />
  </div>
);

export default MotorizadoPanel;
