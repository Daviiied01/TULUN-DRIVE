
import React, { useState } from 'react';
import { Carrera, User, Restaurant, TarifaConfig, CarreraStatus, UserRole, TarifaType, Liquidacion, LiquidacionStatus, IncentiveChallenge, RewardType, RateRange } from '../types';

interface AdminPanelProps {
  carreras: Carrera[];
  users: User[];
  restaurants: Restaurant[];
  tarifas: TarifaConfig[];
  liquidaciones: Liquidacion[];
  incentives: IncentiveChallenge[];
  setIncentives: React.Dispatch<React.SetStateAction<IncentiveChallenge[]>>;
  onUpdateStatus: (id: string, status: CarreraStatus) => void;
  onProcessPayment: (liqId: string, voucher: string) => void;
  onToggleUser: (id: string) => void;
  onAddUser: (userData: Omit<User, 'id' | 'active'>) => void;
  onAddRestaurant: (restData: Omit<Restaurant, 'id' | 'active'>) => void;
  onGenerateReport: (type: 'motorizado' | 'restaurant' | 'general', filterId?: string) => void;
  onRegisterCarrera: (data: Partial<Carrera>, targetMotorizado?: { id: string, name: string }) => void;
  setRestaurants: React.Dispatch<React.SetStateAction<Restaurant[]>>;
  setTarifas: React.Dispatch<React.SetStateAction<TarifaConfig[]>>;
}

const AdminPanel: React.FC<AdminPanelProps> = ({ 
  carreras, users, restaurants, tarifas, liquidaciones, incentives, setIncentives,
  onUpdateStatus, onProcessPayment, onToggleUser, onAddUser, onAddRestaurant, onGenerateReport, onRegisterCarrera, setRestaurants, setTarifas
}) => {
  const [activeTab, setActiveTab] = useState<'dashboard' | 'approvals' | 'incentives' | 'users' | 'tarifas' | 'restaurants' | 'reports'>('dashboard');
  const [showManualForm, setShowManualForm] = useState(false);
  const getToday = () => new Date().toISOString().split('T')[0];

  // --- ESTADOS DE FORMULARIOS ---
  const initialManualState = { motorizadoId: '', restaurantId: '', clientName: '', pointA: '', pointB: '', km: '', date: getToday() };
  const [manualCarrera, setManualCarrera] = useState(initialManualState);
  const [newUser, setNewUser] = useState({ name: '', email: '', password: '', role: UserRole.MOTORIZADO });
  const [newRest, setNewRest] = useState({ name: '', imageUrl: '', defaultTarifa: TarifaType.ESTANDAR });
  const [editingRest, setEditingRest] = useState<Restaurant | null>(null);

  // Estados para Reportes
  const [repMot, setRepMot] = useState('');
  const [repRes, setRepRes] = useState('');

  // Tarifas Dinámicas
  const [showTarifaForm, setShowTarifaForm] = useState(false);
  const [newTarifaName, setNewTarifaName] = useState('');
  const [newRanges, setNewRanges] = useState<RateRange[]>([]);
  const [tempRange, setTempRange] = useState({ minKm: 0, maxKm: 5, price: 0 });

  // Incentivos
  const [newInc, setNewInc] = useState({ title: '', description: '', goal: 10, rewardValue: '', date: getToday() });

  // --- LÓGICA DE ESTADÍSTICAS ---
  const stats = (() => {
    const today = getToday();
    const approved = carreras.filter(c => (c.status === CarreraStatus.APROBADA || c.status === CarreraStatus.LIQUIDADA));
    const todayCarreras = approved.filter(c => c.date.startsWith(today));
    
    const revenue = todayCarreras.reduce((s, c) => s + c.price, 0);
    const cost = todayCarreras.reduce((s, c) => s + (c.motorizadoEarnings || 0), 0);
    const count = todayCarreras.filter(c => c.restaurantId !== 'incentivo').length;
    
    return { revenue, cost, profit: revenue - cost, count };
  })();

  const recentCarreras = [...carreras]
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
    .slice(0, 15);

  // --- MANEJADORES ---
  const handleRegisterManual = () => {
    const mot = users.find(u => u.id === manualCarrera.motorizadoId);
    if (!mot || !manualCarrera.restaurantId || !manualCarrera.km || !manualCarrera.pointA || !manualCarrera.pointB) {
      alert("Por favor, complete todos los campos incluyendo Origen y Destino.");
      return;
    }
    onRegisterCarrera({ ...manualCarrera, km: parseFloat(manualCarrera.km) }, { id: mot.id, name: mot.name });
    setManualCarrera(initialManualState);
    setShowManualForm(false);
  };

  const handleAddUser = () => {
    if (!newUser.name || !newUser.email || !newUser.password) {
      alert("Nombre, Correo y Contraseña son obligatorios.");
      return;
    }
    onAddUser(newUser);
    setNewUser({ name: '', email: '', password: '', role: UserRole.MOTORIZADO });
  };

  const handleSaveRestaurant = () => {
    if (editingRest) {
      setRestaurants(prev => prev.map(r => r.id === editingRest.id ? editingRest : r));
      setEditingRest(null);
    } else {
      if (!newRest.name || !newRest.imageUrl) { alert("Nombre y URL de imagen son obligatorios."); return; }
      onAddRestaurant(newRest);
      setNewRest({ name: '', imageUrl: '', defaultTarifa: TarifaType.ESTANDAR });
    }
  };

  const handleSaveTarifa = () => {
    if (!newTarifaName || newRanges.length === 0) { alert("Asigne un nombre y al menos un rango."); return; }
    const config: TarifaConfig = {
      type: (newTarifaName.toUpperCase().replace(/\s+/g, '_') + '_' + Date.now()) as TarifaType,
      name: newTarifaName,
      ranges: newRanges
    };
    setTarifas(prev => [...prev, config]);
    setNewTarifaName(''); setNewRanges([]); setShowTarifaForm(false);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      {/* NAVEGACIÓN */}
      <div className="flex flex-col md:flex-row md:items-center justify-between mb-8 gap-4">
        <div>
          <h1 className="text-3xl font-black text-slate-800 tracking-tighter uppercase leading-none">MotoGestion Admin</h1>
          <p className="text-[10px] font-bold text-slate-400 mt-1 uppercase tracking-widest">Panel de Control de Operaciones</p>
        </div>
        <div className="flex bg-white p-1 rounded-2xl shadow-sm border border-slate-200 overflow-x-auto no-scrollbar">
          <TabBtn icon="fa-chart-line" label="Resumen" active={activeTab === 'dashboard'} onClick={() => setActiveTab('dashboard')} />
          <TabBtn icon="fa-check-double" label="Aprobaciones" active={activeTab === 'approvals'} onClick={() => setActiveTab('approvals')} badge={carreras.filter(c => c.status === CarreraStatus.PENDIENTE).length} />
          <TabBtn icon="fa-users" label="Personal" active={activeTab === 'users'} onClick={() => setActiveTab('users')} />
          <TabBtn icon="fa-store" label="Locales" active={activeTab === 'restaurants'} onClick={() => setActiveTab('restaurants')} />
          <TabBtn icon="fa-tags" label="Tarifas" active={activeTab === 'tarifas'} onClick={() => setActiveTab('tarifas')} />
          <TabBtn icon="fa-star" label="Incentivos" active={activeTab === 'incentives'} onClick={() => setActiveTab('incentives')} />
          <TabBtn icon="fa-file-pdf" label="Reportes" active={activeTab === 'reports'} onClick={() => setActiveTab('reports')} />
        </div>
      </div>

      <div className="bg-white rounded-3xl shadow-sm border border-slate-100 p-8 min-h-[60vh]">
        
        {/* DASHBOARD */}
        {activeTab === 'dashboard' && (
          <div className="space-y-8 animate-in fade-in">
            <div className="flex justify-between items-center">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-indigo-600 rounded-2xl flex items-center justify-center text-white shadow-lg">
                  <span className="text-xl font-black">{stats.count}</span>
                </div>
                <h2 className="text-xl font-black text-slate-800 uppercase tracking-tight">Actividad Reciente</h2>
              </div>
              <button onClick={() => setShowManualForm(!showManualForm)} className="bg-slate-900 text-white px-6 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest shadow-xl hover:bg-slate-800 transition-all">
                {showManualForm ? 'Cerrar Registro' : 'Nueva Carrera Manual'}
              </button>
            </div>

            {showManualForm && (
              <div className="bg-indigo-50/50 p-6 rounded-3xl border border-indigo-100 grid grid-cols-1 md:grid-cols-4 gap-4 animate-in slide-in-from-top-4">
                <ManualInput label="Motorizado" type="select" value={manualCarrera.motorizadoId} onChange={v => setManualCarrera({...manualCarrera, motorizadoId: v})} options={users.filter(u => u.role === UserRole.MOTORIZADO && u.active).map(u => ({label: u.name, value: u.id}))} />
                <ManualInput label="Local" type="select" value={manualCarrera.restaurantId} onChange={v => setManualCarrera({...manualCarrera, restaurantId: v})} options={restaurants.filter(r => r.active).map(r => ({label: r.name, value: r.id}))} />
                <ManualInput label="KM" type="number" value={manualCarrera.km} onChange={v => setManualCarrera({...manualCarrera, km: v})} />
                <ManualInput label="Cliente" type="text" value={manualCarrera.clientName} onChange={v => setManualCarrera({...manualCarrera, clientName: v})} />
                <ManualInput label="Origen (A)" type="text" value={manualCarrera.pointA} onChange={v => setManualCarrera({...manualCarrera, pointA: v})} />
                <ManualInput label="Destino (B)" type="text" value={manualCarrera.pointB} onChange={v => setManualCarrera({...manualCarrera, pointB: v})} />
                <ManualInput label="Fecha" type="date" value={manualCarrera.date} onChange={v => setManualCarrera({...manualCarrera, date: v})} />
                <button onClick={handleRegisterManual} className="bg-indigo-600 text-white font-black py-3.5 rounded-xl uppercase text-[10px] tracking-widest shadow-lg mt-auto hover:bg-indigo-700 transition-all">Registrar</button>
              </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <DashCard label="Facturación Hoy" value={stats.revenue} color="bg-indigo-600" icon="fa-cash-register" />
              <DashCard label="Pago a Flota" value={stats.cost} color="bg-rose-500" icon="fa-motorcycle" />
              <DashCard label="Utilidad Estimada" value={stats.profit} color="bg-emerald-600" icon="fa-chart-pie" />
            </div>

            <div className="overflow-x-auto border rounded-2xl">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 border-b">
                  <tr className="text-[9px] font-black text-slate-400 uppercase tracking-widest">
                    <th className="px-6 py-4">Fecha</th>
                    <th className="px-6 py-4">Motorizado</th>
                    <th className="px-6 py-4">Local</th>
                    <th className="px-6 py-4">Distancia</th>
                    <th className="px-6 py-4">Cobro Local</th>
                    <th className="px-6 py-4">Pago Mot</th>
                    <th className="px-6 py-4 text-right">Estado</th>
                  </tr>
                </thead>
                <tbody className="divide-y">
                  {recentCarreras.map(c => (
                    <tr key={c.id} className="hover:bg-slate-50 transition-colors">
                      <td className="px-6 py-4 text-slate-500">{new Date(c.date).toLocaleDateString()}</td>
                      <td className="px-6 py-4 font-black text-slate-800 uppercase">{c.motorizadoName}</td>
                      <td className="px-6 py-4 font-bold text-slate-600">{c.restaurantName}</td>
                      <td className="px-6 py-4 text-indigo-400 font-black">{c.km} KM</td>
                      <td className="px-6 py-4 font-black text-indigo-600">${c.price.toFixed(2)}</td>
                      <td className="px-6 py-4 font-black text-emerald-600">${(c.motorizadoEarnings || 0).toFixed(2)}</td>
                      <td className="px-6 py-4 text-right">
                        <span className={`text-[8px] font-black px-2 py-0.5 rounded-full uppercase ${c.status === CarreraStatus.PENDIENTE ? 'bg-amber-100 text-amber-600' : 'bg-emerald-100 text-emerald-600'}`}>
                          {c.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* PERSONAL */}
        {activeTab === 'users' && (
          <div className="space-y-8 animate-in fade-in">
            <div className="bg-slate-50 p-6 rounded-3xl border border-dashed border-slate-300 grid grid-cols-1 md:grid-cols-4 gap-4 items-end">
               <ManualInput label="Nombre" type="text" value={newUser.name} onChange={v => setNewUser({...newUser, name: v})} />
               <ManualInput label="Email" type="text" value={newUser.email} onChange={v => setNewUser({...newUser, email: v})} />
               <ManualInput label="Contraseña" type="password" value={newUser.password} onChange={v => setNewUser({...newUser, password: v})} />
               <div className="flex gap-2">
                 <ManualInput label="Rol" type="select" value={newUser.role} onChange={v => setNewUser({...newUser, role: v as UserRole})} options={[{label:'Motorizado', value:UserRole.MOTORIZADO}, {label:'Admin', value:UserRole.ADMIN}]} />
                 <button onClick={handleAddUser} className="bg-slate-900 text-white h-[46px] px-6 rounded-xl font-black uppercase text-[10px] shadow-lg mt-auto hover:bg-slate-800 transition-all">Crear</button>
               </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
               {users.map(u => (
                 <div key={u.id} className="p-4 border-2 border-slate-100 rounded-2xl flex justify-between items-center bg-white shadow-sm">
                    <div className="overflow-hidden">
                       <p className="font-black text-slate-800 uppercase text-xs truncate">{u.name}</p>
                       <p className="text-[10px] text-slate-400 font-bold uppercase">{u.role} • {u.active ? 'Activo' : 'Inactivo'}</p>
                    </div>
                    <button onClick={() => onToggleUser(u.id)} className={`w-12 h-6 rounded-full relative transition-all ${u.active ? 'bg-indigo-600' : 'bg-slate-300'}`}>
                       <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all ${u.active ? 'left-7' : 'left-1'}`}></div>
                    </button>
                 </div>
               ))}
            </div>
          </div>
        )}

        {/* LOCALES */}
        {activeTab === 'restaurants' && (
          <div className="space-y-8 animate-in fade-in">
            <div className="bg-slate-50 p-6 rounded-3xl border border-dashed border-slate-300 grid grid-cols-1 md:grid-cols-4 gap-4 items-end">
               <ManualInput label="Nombre del Local" type="text" value={editingRest ? editingRest.name : newRest.name} onChange={v => editingRest ? setEditingRest({...editingRest, name: v}) : setNewRest({...newRest, name: v})} />
               <ManualInput label="URL de Imagen" type="text" value={editingRest ? editingRest.imageUrl : newRest.imageUrl} onChange={v => editingRest ? setEditingRest({...editingRest, imageUrl: v}) : setNewRest({...newRest, imageUrl: v})} />
               <ManualInput label="Tarifa Base" type="select" value={editingRest ? editingRest.defaultTarifa : newRest.defaultTarifa} onChange={v => editingRest ? setEditingRest({...editingRest, defaultTarifa: v as TarifaType}) : setNewRest({...newRest, defaultTarifa: v as TarifaType})} options={tarifas.map(t => ({label: t.name, value: t.type}))} />
               <div className="flex gap-2">
                 <button onClick={handleSaveRestaurant} className="flex-grow bg-indigo-600 text-white h-[46px] px-6 rounded-xl font-black uppercase text-[10px] shadow-lg hover:bg-indigo-700 transition-all">
                   {editingRest ? 'Guardar' : 'Añadir'}
                 </button>
                 {editingRest && <button onClick={() => setEditingRest(null)} className="bg-slate-200 px-4 rounded-xl text-slate-600 font-black">X</button>}
               </div>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
               {restaurants.map(r => (
                 <div key={r.id} className="border-2 border-slate-100 rounded-3xl overflow-hidden bg-white shadow-sm group relative">
                    <div className="h-32 relative overflow-hidden bg-slate-200">
                       <img src={r.imageUrl || 'https://via.placeholder.com/150'} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" />
                       <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity">
                          <button onClick={() => setEditingRest(r)} className="bg-white text-slate-800 px-4 py-1.5 rounded-full text-[10px] font-black uppercase shadow-lg">Editar</button>
                       </div>
                    </div>
                    <div className="p-4">
                       <p className="font-black uppercase text-[11px] text-slate-800 truncate">{r.name}</p>
                       <span className={`text-[8px] font-black px-2 py-0.5 rounded-full uppercase ${r.active ? 'bg-emerald-100 text-emerald-600' : 'bg-rose-100 text-rose-600'}`}>{r.active ? 'Activo' : 'Pausado'}</span>
                    </div>
                 </div>
               ))}
            </div>
          </div>
        )}

        {/* TARIFAS */}
        {activeTab === 'tarifas' && (
          <div className="space-y-8 animate-in fade-in">
             <div className="flex justify-between items-center">
                <h2 className="text-xl font-black text-slate-800 uppercase tracking-tight">Estructura Tarifaria</h2>
                <button onClick={() => setShowTarifaForm(!showTarifaForm)} className="bg-indigo-600 text-white px-6 py-2.5 rounded-xl text-[10px] font-black uppercase shadow-lg hover:bg-indigo-700 transition-all">
                  {showTarifaForm ? 'Cerrar Editor' : 'Crear Nueva Tarifa'}
                </button>
             </div>
             {showTarifaForm && (
               <div className="bg-slate-900 text-white p-8 rounded-3xl grid grid-cols-1 md:grid-cols-2 gap-8 shadow-2xl animate-in zoom-in-95">
                  <div className="space-y-4">
                    <ManualInput dark label="Nombre del Esquema" type="text" value={newTarifaName} onChange={setNewTarifaName} />
                    <div className="bg-white/5 p-4 rounded-xl border border-white/10">
                       <div className="grid grid-cols-3 gap-2">
                          <ManualInput dark label="KM Min" type="number" value={tempRange.minKm} onChange={v => setTempRange({...tempRange, minKm: parseFloat(v)})} />
                          <ManualInput dark label="KM Max" type="number" value={tempRange.maxKm} onChange={v => setTempRange({...tempRange, maxKm: parseFloat(v)})} />
                          <ManualInput dark label="Precio $" type="number" value={tempRange.price} onChange={v => setTempRange({...tempRange, price: parseFloat(v)})} />
                       </div>
                       <button onClick={() => { 
                         if(tempRange.maxKm <= tempRange.minKm) return alert("El KM Max debe ser mayor al Min.");
                         setNewRanges([...newRanges, tempRange]); 
                         setTempRange({minKm: tempRange.maxKm, maxKm: tempRange.maxKm + 5, price: 0}); 
                       }} className="w-full mt-3 bg-indigo-600 py-2 rounded-xl text-[9px] font-black uppercase shadow-lg hover:bg-indigo-500 transition-all">+ Añadir Tramo</button>
                    </div>
                  </div>
                  <div className="flex flex-col">
                    <p className="text-[10px] font-bold text-slate-500 uppercase mb-4 tracking-widest">Resumen Estructural:</p>
                    <div className="flex-grow space-y-2 mb-4 overflow-y-auto max-h-[200px] pr-2 no-scrollbar">
                      {newRanges.map((r, i) => (
                        <div key={i} className="flex justify-between items-center bg-white/5 p-3 rounded-xl text-xs font-bold border border-white/5">
                           <span>{r.minKm.toFixed(1)} - {r.maxKm.toFixed(1)} KM</span>
                           <span className="text-emerald-400 font-black">${r.price.toFixed(2)}</span>
                        </div>
                      ))}
                      {newRanges.length === 0 && <p className="text-center py-10 text-slate-500 italic text-[10px]">Sin tramos definidos aún.</p>}
                    </div>
                    <button onClick={handleSaveTarifa} className="w-full bg-emerald-500 text-white py-4 rounded-2xl font-black uppercase text-[11px] shadow-xl hover:bg-emerald-600 transition-all">Guardar Tarifario Maestro</button>
                  </div>
               </div>
             )}
             <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {tarifas.map(t => (
                  <div key={t.type} className="bg-slate-50 p-6 rounded-3xl border-2 border-slate-100 group hover:border-indigo-200 transition-all">
                    <h4 className="font-black text-indigo-600 uppercase text-sm mb-4">{t.name}</h4>
                    <div className="space-y-1.5">
                      {t.ranges.map((r, i) => (
                        <div key={i} className="flex justify-between items-center bg-white p-2.5 rounded-xl text-[10px] font-bold shadow-sm">
                           <span className="text-slate-500">{r.minKm}-{r.maxKm} KM</span>
                           <span className="text-indigo-600 font-black">${r.price.toFixed(2)}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
             </div>
          </div>
        )}

        {/* INCENTIVOS - REINSTALADO Y CORREGIDO */}
        {activeTab === 'incentives' && (
          <div className="space-y-8 animate-in fade-in">
             <div className="bg-slate-900 text-white p-8 rounded-3xl shadow-xl">
              <h3 className="text-lg font-black uppercase mb-6 tracking-tight">Programar Desafío para la Flota</h3>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4 items-end">
                <ManualInput dark label="Título del Incentivo" type="text" value={newInc.title} onChange={v => setNewInc({...newInc, title: v})} />
                <ManualInput dark label="Meta (Nº Carreras)" type="number" value={newInc.goal} onChange={v => setNewInc({...newInc, goal: parseInt(v)})} />
                <ManualInput dark label="Fecha de Ejecución" type="date" value={newInc.date} onChange={v => setNewInc({...newInc, date: v})} />
                <div className="flex gap-2">
                   <ManualInput dark label="Premio $" type="number" value={newInc.rewardValue} onChange={v => setNewInc({...newInc, rewardValue: v})} />
                   <button onClick={() => {
                     if (!newInc.title || !newInc.rewardValue || !newInc.date) return alert("Por favor, rellene todos los campos del incentivo.");
                     const incentive: IncentiveChallenge = {
                        id: Math.random().toString(36).substr(2, 9),
                        title: newInc.title,
                        description: `Completar ${newInc.goal} carreras el ${newInc.date}`,
                        goal: newInc.goal,
                        rewardType: RewardType.MONETARY,
                        rewardValue: parseFloat(newInc.rewardValue),
                        isActive: true,
                        date: newInc.date
                     };
                     setIncentives(prev => [incentive, ...prev]);
                     setNewInc({ title: '', description: '', goal: 10, rewardValue: '', date: getToday() });
                     alert("¡Incentivo lanzado exitosamente!");
                   }} className="bg-indigo-600 h-[46px] w-14 flex items-center justify-center rounded-xl font-black shadow-lg hover:bg-indigo-500 transition-all"><i className="fas fa-plus"></i></button>
                </div>
              </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
               {(incentives || []).map(inc => (
                 <div key={inc.id} className="p-6 border-2 border-slate-100 rounded-3xl bg-white shadow-sm relative group overflow-hidden hover:border-indigo-200 transition-all">
                    <div className="flex justify-between items-start mb-4">
                       <h4 className="font-black text-slate-800 uppercase text-sm leading-tight max-w-[70%]">{inc.title}</h4>
                       <span className="bg-indigo-100 text-indigo-700 px-3 py-1 rounded-full text-[10px] font-black shadow-sm">${inc.rewardValue}</span>
                    </div>
                    <div className="space-y-1.5 mb-4">
                       <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest"><i className="far fa-calendar-alt mr-2 text-indigo-500"></i>Válido: {inc.date}</p>
                       <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest"><i className="fas fa-bullseye mr-2 text-rose-500"></i>Objetivo: {inc.goal} Carreras</p>
                    </div>
                    <button onClick={() => setIncentives(prev => prev.filter(i => i.id !== inc.id))} className="text-[9px] font-black text-rose-500 uppercase opacity-0 group-hover:opacity-100 transition-opacity">Dar de baja desafío</button>
                 </div>
               ))}
               {(!incentives || incentives.length === 0) && <p className="col-span-3 text-center py-10 text-slate-300 font-bold uppercase text-xs">No hay incentivos activos</p>}
            </div>
          </div>
        )}

        {/* REPORTES - CORREGIDO SELECCIÓN DINÁMICA */}
        {activeTab === 'reports' && (
          <div className="space-y-8 animate-in fade-in">
            <h2 className="text-xl font-black text-slate-800 uppercase tracking-tight">Centro de Reportes PDF</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <ReportBox title="General" desc="Consolidado total del sistema" icon="fa-globe" color="bg-slate-900" onGen={() => onGenerateReport('general')} />
              <ReportBox title="Motorizado" desc="Detalle por personal de flota" icon="fa-user-ninja" color="bg-emerald-600" select={
                <select className="w-full text-xs font-bold p-2.5 border rounded-xl outline-none" value={repMot} onChange={e => setRepMot(e.target.value)}>
                  <option value="">Seleccionar Motorizado...</option>
                  {users.filter(u => u.role === UserRole.MOTORIZADO).map(u => <option key={u.id} value={u.id}>{u.name}</option>)}
                </select>
              } onGen={() => onGenerateReport('motorizado', repMot)} disabled={!repMot} />
              <ReportBox title="Comercios" desc="Detalle por local afiliado" icon="fa-store" color="bg-indigo-600" select={
                <select className="w-full text-xs font-bold p-2.5 border rounded-xl outline-none" value={repRes} onChange={e => setRepRes(e.target.value)}>
                  <option value="">Seleccionar Local...</option>
                  {restaurants.map(r => <option key={r.id} value={r.id}>{r.name}</option>)}
                </select>
              } onGen={() => onGenerateReport('restaurant', repRes)} disabled={!repRes} />
            </div>
          </div>
        )}

        {/* APROBACIONES - CON VALORES VISIBLES */}
        {activeTab === 'approvals' && (
           <div className="space-y-6 animate-in fade-in">
              <h2 className="text-xl font-black text-slate-800 uppercase">Solicitudes de Registro Pendientes</h2>
              <div className="grid gap-4">
                {carreras.filter(c => c.status === CarreraStatus.PENDIENTE).map(c => (
                   <div key={c.id} className="p-6 bg-white border-2 border-slate-50 rounded-3xl flex flex-col md:flex-row justify-between items-start md:items-center shadow-sm hover:border-indigo-100 transition-all gap-4">
                      <div className="flex-grow">
                         <div className="flex items-center gap-2 mb-1">
                            <span className="text-[10px] font-black text-indigo-500 uppercase tracking-widest">{c.motorizadoName}</span>
                            <span className="w-1 h-1 bg-slate-300 rounded-full"></span>
                            <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{new Date(c.date).toLocaleDateString()}</span>
                         </div>
                         <h4 className="text-lg font-black text-slate-800 uppercase leading-none">{c.restaurantName} → {c.clientName}</h4>
                         <p className="text-[10px] font-bold text-slate-400 mt-2 uppercase tracking-tight">Ruta: {c.pointA} a {c.pointB} ({c.km} KM)</p>
                         
                         {/* VALORES DE APROBACIÓN DESTACADOS */}
                         <div className="mt-4 flex flex-wrap gap-3">
                            <div className="bg-indigo-50 px-4 py-2 rounded-xl border border-indigo-100 shadow-sm">
                               <p className="text-[8px] font-black text-indigo-400 uppercase leading-none mb-1">Cobro al Local</p>
                               <p className="text-base font-black text-indigo-600 leading-none">${c.price.toFixed(2)}</p>
                            </div>
                            <div className="bg-emerald-50 px-4 py-2 rounded-xl border border-emerald-100 shadow-sm">
                               <p className="text-[8px] font-black text-emerald-400 uppercase leading-none mb-1">Pago Motorizado</p>
                               <p className="text-base font-black text-emerald-600 leading-none">${c.motorizadoEarnings.toFixed(2)}</p>
                            </div>
                            <div className="bg-slate-50 px-4 py-2 rounded-xl border border-slate-100">
                               <p className="text-[8px] font-black text-slate-400 uppercase leading-none mb-1">Utilidad Sistema</p>
                               <p className="text-base font-black text-slate-600 leading-none">${(c.price - c.motorizadoEarnings).toFixed(2)}</p>
                            </div>
                         </div>
                      </div>
                      <div className="flex gap-2 w-full md:w-auto">
                         <button onClick={() => onUpdateStatus(c.id, CarreraStatus.APROBADA)} className="flex-grow md:flex-none bg-emerald-600 text-white px-8 py-3 rounded-xl text-[10px] font-black uppercase shadow-lg hover:bg-emerald-700 transition-all">Aprobar</button>
                         <button onClick={() => onUpdateStatus(c.id, CarreraStatus.RECHAZADA)} className="flex-grow md:flex-none bg-rose-100 text-rose-600 px-8 py-3 rounded-xl text-[10px] font-black uppercase hover:bg-rose-200 transition-all">Rechazar</button>
                      </div>
                   </div>
                ))}
                {carreras.filter(c => c.status === CarreraStatus.PENDIENTE).length === 0 && <p className="text-center py-20 text-slate-300 font-bold uppercase text-xs">No hay registros pendientes por validar</p>}
              </div>
           </div>
        )}

      </div>
    </div>
  );
};

// COMPONENTES AUXILIARES
const DashCard = ({ label, value, color, icon }: any) => (
  <div className={`p-6 rounded-3xl ${color} shadow-2xl relative overflow-hidden transition-all hover:scale-[1.02] group`}>
    <i className={`fas ${icon} absolute -right-4 -bottom-4 text-8xl opacity-10 group-hover:rotate-12 transition-transform`}></i>
    <p className="text-[10px] font-black uppercase opacity-60 mb-1 text-white tracking-widest">{label}</p>
    <h3 className="text-3xl font-black text-white tracking-tighter">${value.toFixed(2)}</h3>
  </div>
);

const TabBtn = ({ icon, label, active, onClick, badge }: any) => (
  <button onClick={onClick} className={`flex items-center space-x-2 px-5 py-3 rounded-xl font-black text-[10px] uppercase tracking-widest relative whitespace-nowrap transition-all ${active ? 'bg-indigo-600 text-white shadow-xl' : 'text-slate-400 hover:bg-slate-50'}`}>
    <i className={`fas ${icon}`}></i><span>{label}</span>
    {badge > 0 && <span className="absolute -top-1.5 -right-1.5 bg-rose-500 text-white text-[8px] w-5 h-5 flex items-center justify-center rounded-full border-2 border-white font-bold">{badge}</span>}
  </button>
);

const ManualInput = ({ label, type, value, onChange, options, dark }: any) => (
  <div className="space-y-1.5 w-full">
    <label className={`text-[9px] font-black uppercase ml-1 ${dark ? 'text-slate-400' : 'text-slate-500'}`}>{label}</label>
    {type === 'select' ? (
      <select className={`w-full px-4 py-3 rounded-xl text-xs font-bold outline-none border ${dark ? 'bg-white/10 border-white/10 text-white' : 'bg-white border-slate-200 text-slate-800'}`} value={value} onChange={e => onChange(e.target.value)}>
        <option value="" className="text-slate-800">Seleccione...</option>
        {options?.map((o: any) => <option key={o.value} value={o.value} className="text-slate-800">{o.label}</option>)}
      </select>
    ) : (
      <input type={type} step="0.01" className={`w-full px-4 py-3 rounded-xl text-xs font-bold outline-none border ${dark ? 'bg-white/10 border-white/10 text-white' : 'bg-white border-slate-200 text-slate-800'}`} value={value} onChange={e => onChange(e.target.value)} />
    )}
  </div>
);

const ReportBox = ({ title, desc, icon, color, select, onGen, disabled }: any) => (
  <div className="bg-slate-50 p-8 rounded-3xl border-2 border-dashed border-slate-200 flex flex-col items-center text-center transition-all hover:border-indigo-300">
    <div className={`w-14 h-14 ${color} rounded-2xl flex items-center justify-center text-white mb-6 shadow-xl`}><i className={`fas ${icon} text-2xl`}></i></div>
    <h3 className="text-lg font-black uppercase tracking-tight text-slate-800 mb-2">{title}</h3>
    <p className="text-xs font-bold text-slate-400 uppercase mb-6 tracking-widest">{desc}</p>
    {select && <div className="w-full mb-4">{select}</div>}
    <button disabled={disabled} onClick={onGen} className="w-full bg-slate-900 text-white py-4 rounded-2xl font-black uppercase text-[10px] tracking-widest shadow-2xl disabled:opacity-30 active:scale-95 transition-all">Generar PDF</button>
  </div>
);

export default AdminPanel;
