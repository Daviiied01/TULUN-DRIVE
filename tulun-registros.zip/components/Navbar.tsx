
import React from 'react';
import { User, UserRole } from '../types';

interface NavbarProps {
  user: User | null;
  onLogout: () => void;
}

const Navbar: React.FC<NavbarProps> = ({ user, onLogout }) => {
  return (
    <nav className="bg-indigo-600 text-white shadow-lg sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16 items-center">
          <div className="flex items-center space-x-2">
            <i className="fas fa-motorcycle text-2xl"></i>
            <span className="text-xl font-bold tracking-tight">MotoGestion</span>
          </div>
          
          {user && (
            <div className="flex items-center space-x-4">
              <div className="hidden sm:block text-right">
                <p className="text-sm font-medium">{user.name}</p>
                <p className="text-xs text-indigo-200 uppercase">{user.role === UserRole.ADMIN ? 'Administrador' : 'Motorizado'}</p>
              </div>
              <button 
                onClick={onLogout}
                className="bg-indigo-700 hover:bg-indigo-800 px-4 py-2 rounded-lg text-sm transition-colors flex items-center space-x-2"
              >
                <i className="fas fa-sign-out-alt"></i>
                <span className="hidden sm:inline">Cerrar Sesión</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
